package pt.unl.fct.di.apdc.firstwebapp.util;


public class RegisterData {

    public String username;
    public String password;
    public String email;
    public String name;
    public String number;
    public String role;
    public RegisterData() {

    }

    public RegisterData(String username, String password, String confirmation, String email, String name,
            String number, String role) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.name = name;
        this.number = number;
        this.role =role;
    }

    public boolean isValid() {
        return !username.equals("") && !password.equals("") && !email.equals("") && !name.equals("")
                && !number.equals("");
    }

    public boolean isEmailValid() {
        return email.contains("@") && email.contains(".");
    }

    public boolean isNumberValid() {
        return number.length() == 9;
    }

}
