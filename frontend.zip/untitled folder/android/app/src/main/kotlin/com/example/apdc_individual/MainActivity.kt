package com.example.apdc_individual

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
