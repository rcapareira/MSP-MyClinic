package pt.unl.fct.di.apdc.firstwebapp.util;

public class RegisterCheckInData {

    public String doctor;
    public String patient;
    public String date;
    public String time;

    public RegisterCheckInData() {

    }

    public RegisterCheckInData(String doctor, String patient, String date, String time) {
        this.doctor = doctor;
        this.patient = patient;
        this.date = date;
        this.time = time;
    }

}
