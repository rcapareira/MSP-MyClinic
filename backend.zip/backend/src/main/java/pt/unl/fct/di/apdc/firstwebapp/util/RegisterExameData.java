package pt.unl.fct.di.apdc.firstwebapp.util;

public class RegisterExameData {

    public String doctor;
    public String patient;
    public String equipment;

    public RegisterExameData() {

    }

    public RegisterExameData(String doctor, String patient, String equipment) {
        this.doctor = doctor;
        this.patient = patient;
        this.equipment = equipment;
    }

}
