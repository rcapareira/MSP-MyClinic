package pt.unl.fct.di.apdc.firstwebapp.resources;

import java.util.logging.Logger;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.cloud.datastore.*;

import pt.unl.fct.di.apdc.firstwebapp.util.RegisterExameData;

@Path("/registerExame")
@Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
public class RegisterExame {
    private static final Logger LOG = Logger.getLogger(RegisterExame.class.getName());
    private final static Datastore datastore = DatastoreOptions.getDefaultInstance().getService();
    private final static KeyFactory userKeyFactory = datastore.newKeyFactory().setKind("Exame");

    public RegisterExame() {
    }

    @Path("/")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response registerRootUser(RegisterExameData data) {
        LOG.fine("Attempt to register exame " + data.doctor);

        Transaction txn = datastore.newTransaction();
        try {
            Key userKey = userKeyFactory.newKey(data.doctor+data.patient+data.equipment);
            Entity user = txn.get(userKey);
            if (user != null) {
                return Response.status(Response.Status.CONFLICT).entity("{\"error\": \"Exame already exists.\"}")
                        .build();
            }
            user = Entity.newBuilder(userKey)
                    .set("doctor", data.doctor)
                    .set("patient", data.patient)
                    .set("equipament", data.equipment)
                    .build();
            txn.add(user);
            txn.commit();
            LOG.fine("Exame " + data.doctor + " registered successfully");
            return Response.ok().build();
        } catch (DatastoreException e) {
            LOG.severe("Error while registering exame: " + e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("{\"error\": \"Error while registering exame\"}").build();
        } finally {
            if (txn.isActive()) {
                txn.rollback();
            }
        }
    }
}
