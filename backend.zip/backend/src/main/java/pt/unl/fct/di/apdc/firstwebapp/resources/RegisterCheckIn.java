package pt.unl.fct.di.apdc.firstwebapp.resources;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.cloud.datastore.*;

import pt.unl.fct.di.apdc.firstwebapp.util.RegisterCheckInData;

import java.util.logging.Logger;

@Path("/checkin")
@Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
public class RegisterCheckIn {

    private static final Logger LOG = Logger.getLogger(LoginResource.class.getName());
    private final static Datastore datastore = DatastoreOptions.getDefaultInstance().getService();
    private final static KeyFactory userKeyFactory = datastore.newKeyFactory().setKind("User");
    private final static KeyFactory apointmentKeyFactory = datastore.newKeyFactory().setKind("DoctorApointment");

    public RegisterCheckIn() {
    }

    @Path("/")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response doCheckIn(RegisterCheckInData data) {
        LOG.fine("Attempt to check in user " + data.patient);
        try {
            Key userKey = userKeyFactory.newKey(data.patient);
            Key apointmentKey = apointmentKeyFactory.newKey(data.doctor + data.patient + data.date + data.time);
            Entity user = datastore.get(userKey);
            if (user == null) {
                LOG.fine("Failed check in attempt for user " + data.patient);
                return Response.status(Response.Status.FORBIDDEN)
                        .entity("{\"error\": \"Incorrect username or password.\"}").build();
            }

            Entity apointment = datastore.get(apointmentKey);
            if (apointment == null) {
                LOG.fine("Failed check in attempt for user " + data.patient);
                return Response.status(Response.Status.FORBIDDEN)
                        .entity("{\"error\": \"Incorrect appointment.\"}").build();
            } else {
                if (apointment.getString("state").equals("done")) {
                    return Response.status(Response.Status.FORBIDDEN)
                            .entity("{\"error\": \"Appointment already done.\"}").build();
                } else {
                    apointment = Entity.newBuilder(apointmentKey)
                            .set("doctor", apointment.getString("doctor"))
                            .set("patient", apointment.getString("patient"))
                            .set("date", apointment.getString("date"))
                            .set("time", apointment.getString("time"))
                            .set("description", apointment.getString("description"))
                            .set("state", "done")
                            .build();
                    datastore.update(apointment);
                }
            }

        } catch (DatastoreException e) {
            LOG.severe("Error while checking in: " + e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("{\"error\": \"Error while checking in.\"}").build();
        }
        return Response.ok().build();
    }
}
