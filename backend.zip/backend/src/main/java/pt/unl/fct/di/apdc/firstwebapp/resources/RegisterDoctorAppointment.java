package pt.unl.fct.di.apdc.firstwebapp.resources;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


import com.google.cloud.datastore.*;


import pt.unl.fct.di.apdc.firstwebapp.util.DoctorAppointmentData;

@Path("/doctorAppointment")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
public class RegisterDoctorAppointment {
    private final static Datastore datastore = DatastoreOptions.getDefaultInstance().getService();
    private final static KeyFactory userKeyFactory = datastore.newKeyFactory().setKind("DoctorAppointment");

    public RegisterDoctorAppointment(){
    }

    @Path("/")
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON + ";charset=utf-8")
    public Response registerDoctorAppointment(DoctorAppointmentData data) {
        if (!data.isValid()) {
            return Response.status(Response.Status.BAD_REQUEST)
                    .entity("{\"error\": \"doctor, patient, date, time, description, state cannot be null\"}").build();
        }

        Transaction txn = datastore.newTransaction();
        try {
            Key userKey = userKeyFactory.newKey(data.doctor + data.patient + data.date + data.time);
            Entity user = txn.get(userKey);
            if (user != null) {
                return Response.status(Response.Status.CONFLICT).entity("{\"error\": \"Doctor appointment already exists.\"}")
                        .build();
            }
            user = Entity.newBuilder(userKey)
                    .set("doctor", data.doctor)
                    .set("patient", data.patient)
                    .set("date", data.date)
                    .set("time", data.time)
                    .set("description", data.description)
                    .set("state", data.state)
                    .build();
            txn.add(user);
            txn.commit();
            return Response.ok().build();
        } catch (DatastoreException e) {
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                    .entity("{\"error\": \"Error while registering doctor appointment\"}").build();
        } finally {
            if (txn.isActive()) {
                txn.rollback();
            }
        }
    }

}

