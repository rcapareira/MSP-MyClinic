package pt.unl.fct.di.apdc.firstwebapp.util;

public class DoctorAppointmentData {

    public String doctor;
    public String patient;
    public String date;
    public String time;
    public String description;
    public String state;

    public DoctorAppointmentData() {

    }

    public DoctorAppointmentData(String doctor, String patient, String date, String time, String description) {
        this.doctor = doctor;
        this.patient = patient;
        this.date = date;
        this.time = time;
        this.description = description;
        this.state = "pending";
    }

    public boolean isValid() {
        return !doctor.equals("") && !patient.equals("") && !date.equals("") && !time.equals("") && !description.equals("") && !state.equals("");
    }

}
