package pt.unl.fct.di.apdc.firstwebapp.util;

public class LogoutData {
    public String cookie;

    public LogoutData() {

    }

    public LogoutData(String cookie) {
        this.cookie = cookie;
    }

}
